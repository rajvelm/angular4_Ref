export class Car {
   /* make: string;
   model: string;
   price: number;
   constructor() { 
   } */
   public id:number;
   public first_name:string;
   public last_name:string;
   public avatar:string;
   
} 