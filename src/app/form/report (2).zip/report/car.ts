export class Car {
   make: String;
   model: String;
   price: Number;
   constructor() { 
   }
} 