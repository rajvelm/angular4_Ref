import { Component, OnInit} from '@angular/core';
import { Observable } from 'rxjs';
import {Http,HttpModule,Response,RequestOptions } from '@angular/http'
import { CarService } from './cars.service';
import { Car } from './car';

@Component({
   selector: 'app-report',
   templateUrl: './report.component.html',
   providers: [CarService] 
})
export class ReportComponent implements OnInit { 
   
   constructor(private carService: CarService) { }
   someProperty:String='';
   ngOnInit()
   {
	   console.log("component:"+this.carService.fetchData());
	  console.log(this.carService.cars);
		this.someProperty=this.carService.myData();
   }
} 




/*import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit
{
	columnDefs = [
        {headerName: 'Make', field: 'make' },
        {headerName: 'Model', field: 'model' },
        {headerName: 'Price', field: 'price'}
    ];

     rowData: any;
	 constructor(private http: Http) {

    }

    ngOnInit() {
       //const url='http://localhost:4200/assets/data/cars.json';
		/*this.http.get(url).subscribe(
		response => {
			console.log(response); 
			//console.log(this.rowData); 
		},
		msg => {
		console.error(`Error: ${msg.status} ${msg.statusText}`);
		}
		);
		this.rowData=this.http.get(url).map((response:response)=>response.json());
		
		console.log("this.rowData"+this.rowData);
    }
}
*/