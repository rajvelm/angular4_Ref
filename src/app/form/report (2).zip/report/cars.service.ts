import { Injectable } from '@angular/core';
import { Http} from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
//import 'rxjs/add/operator/catch';
//import 'rxjs/add/operator/toPromise';
//import { Car } from './car';

@Injectable()
export class CarService {
    constructor(private http:Http)
	{}	
	cars=[
	'Ford', 'CHervlot','Maruthi'
	];
	
	fetchData()
	{
		this.http.get('assets/data/cars.json')
		.subscribe((data)=>console.log(data))
	}
	
	myData()
	{
		return 'This is my data!';
	}
}	
    /*getCarsWithObservable(): Observable<Car[]> {
        return this.http.get(this.url)
	        .map(this.extractData)
	        .catch(this.handleErrorObservable);
    }*/
    /*getCarsWithPromise(): Promise<Car[]> {
        return this.http.get(this.url).toPromise()
	    .then(this.extractData)
	    .catch(this.handleErrorPromise);
    }
    private extractData(res: Response) {
		//console.log("Response:"+res);
		//console.log("/n Body:"+res.config);
		//console.log("/n status ok:"+res.status);

		//let body = res.json(); ----this is procedure for response json conversion but //some json parse problem is there ..dont know why check with this..
		// time being use hardcoded json format
		let body = [
 { make: 'Toyota', model: 'Celica', price: 35000 },
 { make: 'Ford', model: 'Mondeo', price: 32000 },
 { make: 'Porsche', model: 'Boxter', price: 72000 }
];
        return body;
    }
    private handleErrorObservable (error: Response | any) {
	console.error(error.message || error);
	return Observable.throw(error.message || error);
    }
    private handleErrorPromise (error: Response | any) {
	console.error(error.message || error);
	return Promise.reject(error.message || error);
    }	
*/